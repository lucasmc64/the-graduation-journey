package empresa;

import java.util.Scanner;

/**
 *
 * @author lucasmc64
 */

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Funcionario[] funcionarios = new Funcionario[10];
    }
}
